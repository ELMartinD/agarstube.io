These are some of the tampermonkey scripts that I use for Agar.io
Just paste the contents of the script you want to use into tampermonkey and save to use.
From here: https://github.com/Megabyte918
Enjoy :)
